package com.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.service.RestaurantService;

public class RoomGuest {

	public static void main(String[] args) {
		// create the container
		ConfigurableApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

		RestaurantService service = (RestaurantService) context.getBean("ser");

	 System.out.println(service.placeOrder("dosa"));
		 
      context.close();
		 

	}

}
