package com.client;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import com.model.IndianRestaurant;
import com.model.ItalianRestaurant;
import com.service.RestaurantService;

@Configuration
@ComponentScan("com")
public class AppConfig {
	
	@Bean
	@Lazy
	public IndianRestaurant indian() {
		return new IndianRestaurant();
	}
	@Bean
	@Lazy
	public ItalianRestaurant italian() {
		return new ItalianRestaurant();
	}
	@Bean
	//@Scope(value = "prototype")
	public RestaurantService ser() {
		return new RestaurantService(indian());
	}
	

}
