package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.model.Restaurant;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

 
public class RestaurantService {
	
	 
	private Restaurant restaurant;
	
	
	public String placeOrder(String order) {
		return restaurant.prepareOrder(order);
	}
	public RestaurantService(Restaurant restaurant) {
		
		this.restaurant = restaurant;
	}
	@PostConstruct
	public void init() {
		System.out.println("Init Service bean");
	}

   @PreDestroy
	public void destroy() {
		System.out.println("destroy Service bean");
	}
}
