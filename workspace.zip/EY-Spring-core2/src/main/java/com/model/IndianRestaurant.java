package com.model;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
 
public class IndianRestaurant implements Restaurant{

	@Override
	public String prepareOrder(String order) {
		 
		return "Preparing Indian Dish " +order + "with indian hearbs and spices.....!";
	}
	 
	
}
