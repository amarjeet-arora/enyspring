package com.model;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

 
public class ItalianRestaurant implements Restaurant{

	@Override
	public String prepareOrder(String order) {
		 
		return "Preparing Italian Dish "  +order + " with Italian hearbs and spices.....!";
	}
	 
}
