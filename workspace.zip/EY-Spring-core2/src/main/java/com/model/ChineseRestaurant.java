package com.model;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
 
public class ChineseRestaurant implements Restaurant{

	@Override
	public String prepareOrder(String order) {
		// TODO Auto-generated method stub
		return "Preparing Chinese Dish "  +order + " with Chinese hearbs and spices.....!";
	}

	 
 
}
