package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.dao.UserDTO;
import com.model.Users;

@Service
public class UserDaoImpl implements UserDAO {
	@Autowired
	private UserDTO dto;
	
	
	ArrayList<Users> al = new ArrayList<Users>();

	@Override
	public boolean loginValid(Users users) {

		if (users.getUname().equals("admin") && users.getPass().equals("admin123")) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public void registerUser(Users users) {
		dto.save(users);
		System.out.println("User Added");

	}

	@Override
	public List<Users> loadUsers() {
		 
		
		return (List<Users>)dto.findAll();
	}

	@Override
	public boolean findUser(int id) {
		 Optional<Users> findData= dto.findById(id);
		 if(findData.isPresent()) {
			 return true;
		 }
		 return false;
	}

	@Override
	public boolean deleteUser(int id) {
		 
		 Optional<Users> findData= dto.findById(id);
		 if(findData.isPresent()) {
			 dto.deleteById(id);
			 return true;
		 }
		 return false;
	}
	
	public List<Users> getAllUsers(Integer pageNo,Integer pageSize,String sortBy){
		
		Pageable paging= PageRequest.of(pageNo, pageSize,Sort.by(sortBy));
		Page<Users> pageResult= dto.findAll(paging);
		if(pageResult.hasContent()) {
			return pageResult.getContent();
		}else {
			return new ArrayList<Users>();
		}
	}
	
	
	
	

}
