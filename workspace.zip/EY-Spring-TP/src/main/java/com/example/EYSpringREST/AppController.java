package com.example.EYSpringREST;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/genericlient")
public class AppController {
	
	@Autowired
	private DelegateApp app;
    @GetMapping("/ratings")
	public String loadDataFromRatings() {
		return app.callUser();
	}
}
