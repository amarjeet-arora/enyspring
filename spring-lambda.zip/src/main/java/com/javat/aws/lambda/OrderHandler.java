package com.javat.aws.lambda;

import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;

public class OrderHandler extends SpringBootRequestHandler<String,Object> {
}
