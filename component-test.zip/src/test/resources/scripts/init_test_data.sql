INSERT INTO orders (tracking_number, items)
VALUES ('11112', '[{"name": "Item 1", "amount" : 100}, {"name": "Special", "amount" : 200}]');
INSERT INTO orders (tracking_number, items)
VALUES ('11113', '[{"name": "Item 3", "amount" : 120}, {"name": "Special", "amount" : 200}]');
INSERT INTO orders (tracking_number, items)
VALUES ('11114', '[]');
