package com.app;

import lombok.Value;

@Value
public class FulfillmentStatus {

    String trackingNumber;
    String status;
    String smsSent;

}
