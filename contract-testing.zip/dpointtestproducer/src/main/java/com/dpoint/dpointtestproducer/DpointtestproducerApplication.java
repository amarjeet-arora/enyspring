package com.dpoint.dpointtestproducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DpointtestproducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DpointtestproducerApplication.class, args);
	}

}
