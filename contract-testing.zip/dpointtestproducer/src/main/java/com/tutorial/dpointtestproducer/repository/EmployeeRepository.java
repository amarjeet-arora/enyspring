package com.tutorial.dpointtestproducer.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dpoint.dpointtestproducer.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
}
