package com.dpoint.dpointtestconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DpointtestconsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DpointtestconsumerApplication.class, args);
	}

}
