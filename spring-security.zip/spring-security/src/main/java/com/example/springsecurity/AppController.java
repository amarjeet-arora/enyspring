package com.example.springsecurity;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class AppController {
	@GetMapping("/home")
	public String getHomePage() {
		return "home";
	}
	@GetMapping("/welcome")
	public String getWelcomePage() {
		return "welcome";
	}

	@GetMapping("/admin")
	public String getadminPage() {
		return "admin";
	}
	@GetMapping("/employee")
	public String getEmployeePage() {
		return "emp";
	}
	@GetMapping("/common")
	public String getCommonPage() {
		return "common";
	}
	@GetMapping("/manager")
	public String getManagerPage() {
		return "manager";
	}
	@GetMapping("/ad")
	public String getadPage() {
		return "ad";
	}
}
