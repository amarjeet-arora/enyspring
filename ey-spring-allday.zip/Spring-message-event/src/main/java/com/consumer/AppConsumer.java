package com.consumer;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import com.config.MessageConfig;
import com.model.OrderStatus;

@Component
public class AppConsumer {
	@RabbitListener(queues = MessageConfig.QUEUE)
	public void consume(OrderStatus orderStatus) {
		System.out.println("Message From Queue  "+ orderStatus);
	}

}
