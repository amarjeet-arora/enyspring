package com.example.Springmessageevent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMessageEventApplicationTests {

	@Test
	void contextLoads() {
	}

}
