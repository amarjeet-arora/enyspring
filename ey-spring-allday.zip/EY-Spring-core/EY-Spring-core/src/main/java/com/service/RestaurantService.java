package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.model.Restaurant;

@Service("ser")
public class RestaurantService {
	
	@Autowired
	@Qualifier("chinese")
	private Restaurant restaurant;

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
	
	
	public String placeOrder(String order) {
		return restaurant.prepareOrder(order);
	}
	

}
