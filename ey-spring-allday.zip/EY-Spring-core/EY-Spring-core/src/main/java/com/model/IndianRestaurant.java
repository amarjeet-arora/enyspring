package com.model;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component("indian")
@Lazy
public class IndianRestaurant implements Restaurant{

	@Override
	public String prepareOrder(String order) {
		 
		return "Preparing Indian Dish " +order + "with indian hearbs and spices.....!";
	}
	public IndianRestaurant(){
		
		System.out.println("inside indian class");
	}
	
}
