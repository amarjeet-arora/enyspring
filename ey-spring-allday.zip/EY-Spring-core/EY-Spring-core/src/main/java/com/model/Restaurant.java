package com.model;

public interface Restaurant {
	
	public String prepareOrder(String order);

}
