package com.model;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component("italian")
@Lazy
public class ItalianRestaurant implements Restaurant{

	@Override
	public String prepareOrder(String order) {
		 
		return "Preparing Italian Dish "  +order + " with Italian hearbs and spices.....!";
	}
	public ItalianRestaurant(){
		System.out.println("inside italian");
	}
}
