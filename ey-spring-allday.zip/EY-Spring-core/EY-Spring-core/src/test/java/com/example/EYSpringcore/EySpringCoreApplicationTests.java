package com.example.EYSpringcore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EySpringCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
