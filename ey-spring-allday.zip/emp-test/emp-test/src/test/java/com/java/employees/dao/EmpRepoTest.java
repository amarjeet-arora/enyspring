package com.java.employees.dao;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.stereotype.Repository;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.java.employees.model.Employee;
// Testing Repository

@ExtendWith(SpringExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace =AutoConfigureTestDatabase.Replace.NONE )
public class EmpRepoTest {
	
@Autowired	
EmployeeRepository repository;

@Test
public void testCreateCreate() {
	Employee employee= new Employee("Aman", "Gupta");
	repository.save(employee);
	Iterable<Employee> itr= repository.findAll();
	Assertions.assertThat(itr).extracting(Employee:: getFirstName).containsOnly("Aman");
	
	repository.deleteAll();
	Assertions.assertThat(repository.findAll()).isEmpty();
	
}



}
