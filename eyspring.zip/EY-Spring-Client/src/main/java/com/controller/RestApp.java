package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.service.RequestDelegate;
 

 

@RestController
@RequestMapping("/mainapp")
public class RestApp {

	@Autowired
	private RequestDelegate delegate;
	@GetMapping("/loadusers")
	public String loadData() {
		return delegate.callAPI();
	}
	@GetMapping("/loadusersdb")
	public String loadDataDB() {
		return delegate.callAPIDB();
	}
	 
}
