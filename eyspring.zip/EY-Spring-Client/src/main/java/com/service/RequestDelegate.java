package com.service;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class RequestDelegate {
	
	RestTemplate template= new RestTemplate();
	
	public String callAPI() {
		String result=template.exchange(
				"http://localhost:8090/mainapp/loadall",
				HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {
				}).getBody();
		return result;
	}
	
	public String callAPIDB() {
		String result=template.exchange(
				"http://localhost:8070/mainapp/loadall",
				HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {
				}).getBody();
		return result;
	}

}
