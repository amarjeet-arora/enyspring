package com.client;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import lombok.Data;

@Configuration
@ConfigurationProperties("spring.datasource")
@Data
public class AppConfig {
	
	private String driverClassName;
	private String url;
	private String username;
	private String password;
	
    @Bean
    @Profile("prod")
	public String testProdDB() {
    	System.out.println(driverClassName);
    	System.out.println(url);
        return "connected to PROD";		
	}
    @Bean
    @Profile("dev")
	public String testDevDB() {
    	System.out.println(driverClassName);
    	System.out.println(url);
        return "connected to DEV";		
	}
    @Bean
    @Profile("test")
	public String testTestDB() {
    	System.out.println(driverClassName);
    	System.out.println(url);
        return "connected to Test";		
	}
}
